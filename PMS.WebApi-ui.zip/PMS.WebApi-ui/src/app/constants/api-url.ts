export class ApiUrl{
    public static localurl="https://localhost:7291/api/";
}