export class Tasks{
    taskid!:number;
    taskname!:string;
    description!:string;
    duedate!:Date;
    status!:string;
    userid!:number;
    iscompleted!:string;
}