export class Evalquestion{
    evaluatequestionid!:number;
    evaluatequestion!:string;
    evaluatequestiondescription!:string;

}