export class Position{
    positionid!:number;
    positionname!:string;
    positionlevel!:number;
}