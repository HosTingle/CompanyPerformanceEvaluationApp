export interface EntityReponseModelL<T>{ 
    data:T[];
    success:boolean;
    message:string;
}