export class EvaluateSelection{
    evaluatequestionid!:number;
    puan!:number;
    constructor(evaluatequestionid: number, puan: number) {
        this.evaluatequestionid = evaluatequestionid;
        this.puan = puan;
      }
}