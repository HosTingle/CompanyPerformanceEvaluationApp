export interface UserAuthM{
    userauthid:number;
    userid:number;
    username:string;
    passwordhash:string;
    passwordsalt:string;
}
