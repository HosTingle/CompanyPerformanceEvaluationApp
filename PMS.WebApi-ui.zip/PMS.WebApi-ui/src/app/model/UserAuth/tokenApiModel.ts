export class TokenApiModel{
    accessToken!:string;
    refreshToken!:string;
}