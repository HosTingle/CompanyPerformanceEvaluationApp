export class Register{
    username!:string;
    name!:string;
    email!:string;
    birthDate!:Date;
    phone!:string;
    password!:string;
    country!:string;
    city!:string;
    state!:string;
    addressDetail!:string;
    teamid!:string;
    status!:string;
}