export class UserDetail{
    userid!:number;
    name!:string;
    email!:string;
    birthdate!:Date;
    phone!:string;
    country!:string;
    city!:string;
    role!:string;
    imageurl!:string;
    teamname!:string;
    rolelevel!:number; 
    status!:string; 
}