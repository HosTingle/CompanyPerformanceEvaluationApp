export interface Login{
    username:string;
    password:string;
}