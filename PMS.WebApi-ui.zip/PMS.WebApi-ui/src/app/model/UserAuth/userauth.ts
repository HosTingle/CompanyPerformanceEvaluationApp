export interface UserAuth{
    userauthid:number;
    userid:number;
    username:string;
    surname:string;
    city:string;
    email:string;
    dateofbirth:Date;
    country:string;
}
