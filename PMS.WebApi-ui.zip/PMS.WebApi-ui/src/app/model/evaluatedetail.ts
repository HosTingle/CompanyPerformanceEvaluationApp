export class EvaluateDetals{
    evaluateid!:number;
    evaluatorname!:string;
    evaluatorimageurl!:string;
    evaluateename!:string;
    evaluateeimageurl!:string;
    evaluatequestion!:string;
    taskname!:string;
    description!:string;
    feedbackcomment!:string;
    evaluationdate!:Date;
    evaluatescore!:number;
    period!:string;
}