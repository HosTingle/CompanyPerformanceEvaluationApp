export class Evaluate{
    evaluateid!:number;
    evaluatorid!:number;
    evaluateeid!:number;
    evalquestionid!:number;
    taskid!:number;
    feedbackcomment!:string;
    evaluationdate!:Date;
    evaluatescore!:number;
    period!:string;
}